/**
 * Local 825 Intelligence Plugin - Admin JavaScript
 */

jQuery(document).ready(function($) {
    
    // Test MCP Connection
    $('#test-mcp-connection').on('click', function() {
        var button = $(this);
        var originalText = button.text();
        
        button.text('Testing...').prop('disabled', true);
        $('#connection-status').text('Testing...').removeClass('success error');
        
        $.ajax({
            url: local825_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'local825_test_mcp_connection',
                nonce: local825_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#connection-status').text('Connected').addClass('success');
                    $('#last-test').text('Just now');
                    showNotice('MCP connection successful!', 'success');
                } else {
                    $('#connection-status').text('Failed').addClass('error');
                    $('#last-test').text('Just now');
                    showNotice('MCP connection failed: ' + (response.data || 'Unknown error'), 'error');
                }
            },
            error: function() {
                $('#connection-status').text('Error').addClass('error');
                $('#last-test').text('Just now');
                showNotice('MCP connection test failed. Please check your server configuration.', 'error');
            },
            complete: function() {
                button.text(originalText).prop('disabled', false);
            }
        });
    });
    
    // Save Local 825 Companies
    $('#save-local825-companies').on('click', function() {
        var companies = $('#local825-companies').val();
        var button = $(this);
        var originalText = button.text();
        
        button.text('Saving...').prop('disabled', true);
        
        $.ajax({
            url: local825_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'local825_save_local825_companies',
                companies: companies,
                nonce: local825_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('Local 825 companies saved successfully!', 'success');
                    updateCompanyPreview();
                } else {
                    showNotice('Failed to save companies: ' + (response.data || 'Unknown error'), 'error');
                }
            },
            error: function() {
                showNotice('Failed to save companies. Please try again.', 'error');
            },
            complete: function() {
                button.text(originalText).prop('disabled', false);
            }
        });
    });
    
    // Save General Companies
    $('#save-general-companies').on('click', function() {
        var companies = $('#general-companies').val();
        var button = $(this);
        var originalText = button.text();
        
        button.text('Saving...').prop('disabled', true);
        
        $.ajax({
            url: local825_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'local825_save_general_companies',
                companies: companies,
                nonce: local825_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('General companies saved successfully!', 'success');
                    updateCompanyPreview();
                } else {
                    showNotice('Failed to save companies: ' + (response.data || 'Unknown error'), 'error');
                }
            },
            error: function() {
                showNotice('Failed to save companies. Please try again.', 'error');
            },
            complete: function() {
                button.text(originalText).prop('disabled', false);
            }
        });
    });
    
    // Load Local 825 Target Companies
    $('#load-local825-target-companies').on('click', function() {
        var companies = [
            'Skanska USA',
            'Turner Construction',
            'Bechtel Corporation',
            'Fluor Corporation',
            'AECOM',
            'Kiewit Corporation',
            'Walsh Group',
            'Gilbane Building Company',
            'Balfour Beatty',
            'Clark Construction Group',
            'Hensel Phelps',
            'Suffolk Construction',
            'Brasfield & Gorrie',
            'McCarthy Building Companies',
            'DPR Construction',
            'Whiting-Turner Contracting',
            'Barton Malow',
            'JE Dunn Construction',
            'Mortenson Construction',
            'PCL Construction',
            'Webcor Builders',
            'Swinerton Builders',
            'Hunt Construction Group',
            'Brasfield & Gorrie',
            'Robins & Morton',
            'Hoar Construction',
            'Brasfield & Gorrie',
            'Robins & Morton',
            'Hoar Construction',
            'Brasfield & Gorrie'
        ];
        
        $('#local825-companies').val(companies.join('\n'));
        showNotice('Local 825 target companies loaded!', 'success');
    });
    
    // Load General Construction Companies
    $('#load-general-companies').on('click', function() {
        var companies = [
            'Lendlease',
            'Brookfield Properties',
            'Related Companies',
            'Tishman Speyer',
            'Vornado Realty Trust',
            'SL Green Realty',
            'Boston Properties',
            'Hudson Pacific Properties',
            'Kilroy Realty Corporation',
            'Alexandria Real Estate Equities',
            'Crown Castle International',
            'American Tower Corporation',
            'Digital Realty Trust',
            'Equinix',
            'Iron Mountain',
            'Prologis',
            'Public Storage',
            'Extra Space Storage',
            'CubeSmart',
            'Life Storage'
        ];
        
        $('#general-companies').val(companies.join('\n'));
        showNotice('General construction companies loaded!', 'success');
    });
    
    // Reset Settings
    $('#reset-settings').on('click', function() {
        if (confirm('Are you sure you want to reset all settings to defaults? This cannot be undone.')) {
            var button = $(this);
            var originalText = button.text();
            
            button.text('Resetting...').prop('disabled', true);
            
            $.ajax({
                url: local825_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'local825_reset_settings',
                    nonce: local825_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showNotice('Settings reset successfully!', 'success');
                        location.reload();
                    } else {
                        showNotice('Failed to reset settings: ' + (response.data || 'Unknown error'), 'error');
                    }
                },
                error: function() {
                    showNotice('Failed to reset settings. Please try again.', 'error');
                },
                complete: function() {
                    button.text(originalText).prop('disabled', false);
                }
            });
        }
    });
    
    // Update company preview
    function updateCompanyPreview() {
        var local825Companies = $('#local825-companies').val().split('\n').filter(function(company) {
            return company.trim() !== '';
        });
        
        var generalCompanies = $('#general-companies').val().split('\n').filter(function(company) {
            return company.trim() !== '';
        });
        
        $('#local825-companies-preview').html('<ul><li>' + local825Companies.join('</li><li>') + '</li></ul>');
        $('#general-companies-preview').html('<ul><li>' + generalCompanies.join('</li><li>') + '</li></ul>');
    }
    
    // Show notice
    function showNotice(message, type) {
        var noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        var notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');
        
        $('.local825-admin').prepend(notice);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            notice.fadeOut();
        }, 5000);
    }
    
    // Initialize company preview
    updateCompanyPreview();
    
    // Update preview on input change
    $('#local825-companies, #general-companies').on('input', function() {
        updateCompanyPreview();
    });
    
});
