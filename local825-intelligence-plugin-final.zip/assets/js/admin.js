/**
 * Local 825 Intelligence Plugin - Admin JavaScript
 * Simplified version - auto-connects to MCP server
 */

jQuery(document).ready(function($) {
    
    // Load Local 825 Target Companies
    $('#load-local825-target-companies').on('click', function() {
        var companies = [
            'Skanska USA',
            'Turner Construction',
            'Bechtel Corporation',
            'Fluor Corporation',
            'AECOM',
            'Kiewit Corporation',
            'Walsh Group',
            'Gilbane Building Company',
            'Balfour Beatty',
            'Clark Construction Group',
            'Hensel Phelps',
            'Suffolk Construction',
            'Brasfield & Gorrie',
            'McCarthy Building Companies',
            'DPR Construction',
            'Whiting-Turner Contracting',
            'Barton Malow',
            'JE Dunn Construction',
            'Mortenson Construction',
            'PCL Construction',
            'Webcor Builders',
            'Swinerton Builders',
            'Hunt Construction Group',
            'Robins & Morton',
            'Hoar Construction'
        ];
        
        $('#local825-companies').val(companies.join('\n'));
        showNotice('Local 825 target companies loaded!', 'success');
    });
    
    // Load General Construction Companies
    $('#load-general-companies').on('click', function() {
        var companies = [
            'Lendlease',
            'Brookfield Properties',
            'Related Companies',
            'Tishman Speyer',
            'Vornado Realty Trust',
            'SL Green Realty',
            'Boston Properties',
            'Hudson Pacific Properties',
            'Kilroy Realty Corporation',
            'Alexandria Real Estate Equities',
            'Crown Castle International',
            'American Tower Corporation',
            'Digital Realty Trust',
            'Equinix',
            'Iron Mountain',
            'Prologis',
            'Public Storage',
            'Extra Space Storage',
            'CubeSmart',
            'Life Storage'
        ];
        
        $('#general-companies').val(companies.join('\n'));
        showNotice('General construction companies loaded!', 'success');
    });
    
    // Update company preview
    function updateCompanyPreview() {
        var local825Companies = $('#local825-companies').val().split('\n').filter(function(company) {
            return company.trim() !== '';
        });
        
        var generalCompanies = $('#general-companies').val().split('\n').filter(function(company) {
            return company.trim() !== '';
        });
        
        $('#local825-companies-preview').html('<ul><li>' + local825Companies.join('</li><li>') + '</li></ul>');
        $('#general-companies-preview').html('<ul><li>' + generalCompanies.join('</li><li>') + '</li></ul>');
    }
    
    // Show notice
    function showNotice(message, type) {
        var noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        var notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');
        
        $('.local825-admin').prepend(notice);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            notice.fadeOut();
        }, 5000);
    }
    
    // Initialize company preview
    updateCompanyPreview();
    
    // Update preview on input change
    $('#local825-companies, #general-companies').on('input', function() {
        updateCompanyPreview();
    });
    
});
